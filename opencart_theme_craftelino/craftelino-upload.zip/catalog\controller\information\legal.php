<?php
namespace Opencart\Catalog\Controller\Information;

/**
 * Pagini legale Craftelino (fără dependență de înregistrări în admin).
 */
class Legal extends \Opencart\System\Engine\Controller {
	private const COMPANY = [
		'name' => 'OMNITRADE SYSTEMS SRL',
		'cui'  => '52691812',
		'reg'  => 'J2025078332006',
		'addr' => 'Str. Verzisori 6 Bl. D Ap. B118',
	];

	public function index(): void {
		$this->load->language('default');

		$page = isset($this->request->get['page']) ? (string)$this->request->get['page'] : 'terms';

		$pages = $this->getPages();

		if (!isset($pages[$page])) {
			$this->response->redirect($this->url->link('error/not_found', 'language=' . $this->config->get('config_language')));

			return;
		}

		$info = $pages[$page];

		$this->document->setTitle($info['meta_title']);
		$this->document->setDescription($info['meta_description']);

		$data['breadcrumbs'] = [];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home', 'language=' . $this->config->get('config_language'))
		];
		$data['breadcrumbs'][] = [
			'text' => $info['title'],
			'href' => $this->url->link('information/legal', 'language=' . $this->config->get('config_language') . '&page=' . $page)
		];

		$data['heading_title'] = $info['title'];
		$data['description'] = $info['description'];
		$data['continue'] = $this->url->link('common/home', 'language=' . $this->config->get('config_language'));

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('information/legal', $data));
	}

	/**
	 * Linkuri pentru footer (Ajutor).
	 */
	public static function footerLinks(string $language, callable $link): array {
		$base = 'language=' . $language . '&page=';

		return [
			[
				'title' => 'Termeni și condiții',
				'href'  => $link('information/legal', $base . 'terms')
			],
			[
				'title' => 'Informații livrare',
				'href'  => $link('information/legal', $base . 'delivery')
			],
			[
				'title' => 'Politica de confidențialitate',
				'href'  => $link('information/legal', $base . 'privacy')
			],
			[
				'title' => 'Contact',
				'href'  => $link('information/contact', $language)
			],
		];
	}

	public static function company(): array {
		return self::COMPANY;
	}

	private function getPages(): array {
		$c = self::COMPANY;
		$store = $this->config->get('config_name');
		$email = $this->config->get('config_email');
		$phone = $this->config->get('config_telephone');

		$company_block = '<div class="craft-legal-company">'
			. '<p><strong>Denumire:</strong> ' . htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8') . '</p>'
			. '<p><strong>CUI:</strong> ' . htmlspecialchars((string)$c['cui'], ENT_QUOTES, 'UTF-8') . '</p>'
			. '<p><strong>Nr. înregistrare Registrul Comerțului:</strong> ' . htmlspecialchars($c['reg'], ENT_QUOTES, 'UTF-8') . '</p>'
			. '<p><strong>Sediu:</strong> ' . htmlspecialchars($c['addr'], ENT_QUOTES, 'UTF-8') . '</p>';

		if ($email) {
			$company_block .= '<p><strong>E-mail:</strong> <a href="mailto:' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . '</a></p>';
		}

		if ($phone) {
			$company_block .= '<p><strong>Telefon:</strong> ' . htmlspecialchars($phone, ENT_QUOTES, 'UTF-8') . '</p>';
		}

		$company_block .= '</div>';

		return [
			'terms' => [
				'title'           => 'Termeni și condiții',
				'meta_title'      => 'Termeni și condiții',
				'meta_description'=> 'Termeni și condiții de utilizare ' . $store,
				'description'     => $company_block . $this->termsHtml($store)
			],
			'delivery' => [
				'title'           => 'Informații livrare',
				'meta_title'      => 'Informații livrare',
				'meta_description'=> 'Livrare produse promoționale ' . $store,
				'description'     => $company_block . $this->deliveryHtml($store)
			],
			'privacy' => [
				'title'           => 'Politica de confidențialitate',
				'meta_title'      => 'Politica de confidențialitate',
				'meta_description'=> 'Politica de confidențialitate ' . $store,
				'description'     => $company_block . $this->privacyHtml($store)
			],
		];
	}

	private function termsHtml(string $store): string {
		return '<h2>1. Dispoziții generale</h2>
<p>Prezentele termeni și condiții reglementează utilizarea site-ului <strong>' . htmlspecialchars($store, ENT_QUOTES, 'UTF-8') . '</strong> și contractarea comenzilor de produse promoționale personalizate, operate de ' . htmlspecialchars(self::COMPANY['name'], ENT_QUOTES, 'UTF-8') . '.</p>
<h2>2. Comenzi și oferte</h2>
<p>Prețurile afișate sunt orientative pentru produse standard. Pentru personalizare (logo, broderie, serigrafie, gravură), termenul și prețul final se confirmă prin ofertă / machetă aprobată. Comanda devine fermă după confirmarea scrisă (e-mail) a ofertei și, după caz, a plății avansului agreat.</p>
<h2>3. Plata</h2>
<p>Plata se poate efectua prin metodele afișate în checkout (card, transfer bancar etc.). Factura fiscală este emisă conform legislației române în vigoare.</p>
<h2>4. Livrare</h2>
<p>Termenul estimativ de livrare este de 5–7 zile lucrătoare de la confirmarea comenzii și aprobarea machetei, dacă nu se agreează altfel. Detalii suplimentare în pagina Informații livrare.</p>
<h2>5. Personalizare și machete</h2>
<p>Clientul este responsabil pentru corectitudinea fișierelor logo și a datelor de personalizare transmise. Reviziile suplimentare pot genera costuri și prelungirea termenului.</p>
<h2>6. Retur și reclamații</h2>
<p>Produsele personalizate nu pot fi returnate conform art. 16 lit. c) din OUG 34/2014, exceptând cazurile de neconformitate (defect, personalizare greșită din vina noastră). Reclamațiile se transmit în maximum 48 de ore de la recepție, cu dovezi foto.</p>
<h2>7. Proprietate intelectuală</h2>
<p>Materialele grafice ale site-ului aparțin operatorului. Logo-urile clienților rămân proprietatea acestora; clientul garantează că deține drepturile de utilizare.</p>
<h2>8. Lege aplicabilă</h2>
<p>Relațiile contractuale sunt guvernate de legea română. Litigiile se soluționează pe cale amiabilă sau de instanțele competente din România.</p>';
	}

	private function deliveryHtml(string $store): string {
		return '<h2>Livrare în România</h2>
<p>Expediem comenzile către adrese din România prin curier rapid, în funcție de greutate și volum.</p>
<ul>
<li><strong>Termen estimativ:</strong> 5–7 zile lucrătoare de la confirmarea comenzii și aprobarea machetei</li>
<li><strong>Comenzi urgente:</strong> la cerere, în limita stocului — contactați-ne înainte de plasarea comenzii</li>
<li><strong>Cost transport:</strong> calculat la finalizarea comenzii sau inclus în oferta B2B</li>
</ul>
<h2>Ridicare și livrare B2B</h2>
<p>Pentru comenzi corporate cu valoare mare, putem oferi livrare în tranșe sau la sediul indicat. Detaliile se stabilesc în oferta comercială.</p>
<h2>Recepție colet</h2>
<p>Verificați coletul la primire. Eventualele deteriorări vizibile se semnalează imediat curierului și către ' . htmlspecialchars($store, ENT_QUOTES, 'UTF-8') . ' în maximum 48 de ore.</p>';
	}

	private function privacyHtml(string $store): string {
		return '<h2>Operator de date</h2>
<p>Datele cu caracter personal sunt prelucrate de <strong>' . htmlspecialchars(self::COMPANY['name'], ENT_QUOTES, 'UTF-8') . '</strong>, în calitate de operator, conform Regulamentului (UE) 2016/679 (GDPR).</p>
<h2>Date colectate</h2>
<p>Putem prelucra: nume, date firmă, CUI, adresă, telefon, e-mail, date de livrare și facturare, conținutul mesajelor și fișiere logo transmise pentru personalizare.</p>
<h2>Scopuri</h2>
<ul>
<li>procesarea comenzilor și livrărilor</li>
<li>emiterea documentelor fiscale</li>
<li>comunicări comerciale legate de comanda dumneavoastră</li>
<li>îmbunătățirea serviciilor și securității site-ului</li>
</ul>
<h2>Temei legal</h2>
<p>Executarea contractului, obligații legale și interes legitim (marketing direct către clienți existenți, conform legii).</p>
<h2>Durata stocării</h2>
<p>Păstrăm datele pe perioada necesară îndeplinirii contractului și conform termenelor legale de arhivare.</p>
<h2>Drepturile dumneavoastră</h2>
<p>Aveți dreptul de acces, rectificare, ștergere, restricționare, portabilitate și opoziție, precum și dreptul de a depune plângere la ANSPDCP. Solicitările la adresa de e-mail a magazinului.</p>
<h2>Cookie-uri</h2>
<p>Site-ul poate utiliza cookie-uri esențiale și de analiză. Puteți gestiona preferințele din bannerul de cookie-uri sau setările browserului.</p>';
	}
}
